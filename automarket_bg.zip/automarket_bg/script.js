const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let userCars = JSON.parse(localStorage.getItem('automarket_userCars')||'[]');
let favorites = JSON.parse(localStorage.getItem('automarket_favorites')||'[]');
let cars = [...baseCars,...userCars];
let visibleCars = [...cars];


function fillSelects(){
  const brands=[...new Set(cars.map(c=>c.brand))].sort();
  const brandHTML=brands.map(b=>`<option>${b}</option>`).join('');
  $('#brandFilter').innerHTML='<option value="">Всички марки</option>'+brandHTML;
  $('#quickBrand').innerHTML='<option value="">Марка</option>'+brandHTML;
  const years=[];for(let y=2026;y>=1990;y--)years.push(`<option>${y}</option>`);
  $('#yearMin').innerHTML='<option value="">Без значение</option>'+years.join('');
  $('#yearMax').innerHTML='<option value="">Без значение</option>'+years.join('');
  $('#quickYear').innerHTML='<option value="">Година от</option>'+years.join('');
  updateModelSelect();
}
function updateModelSelect(){const brand=$('#brandFilter').value;const models=[...new Set(cars.filter(c=>!brand||c.brand===brand).map(c=>c.model))].sort();$('#modelFilter').innerHTML='<option value="">Всички модели</option>'+models.map(m=>`<option>${m}</option>`).join('')}

function renderCars(list){
  $('#resultCount').textContent=list.length;$('#carsGrid').innerHTML='';
  $('#emptyState').classList.toggle('hidden',list.length>0);
  list.forEach(c=>{
    const fav=favorites.includes(c.id);
    const article=document.createElement('article');article.className='car-card';
    article.innerHTML=`<div class="car-image"><img src="${carImg(c)}" alt="${c.title}" loading="lazy" onerror="this.src='${placeholderImage(c.title)}'"><span class="badge">${c.condition}</span>${c.postedDays===0?'<span class="badge new">Нова днес</span>':''}</div><div class="car-content"><div class="car-title-row"><h3 class="car-title"><a class="title-btn" href="car.html?id=${c.id}">${c.title}</a></h3><div class="price">${formatPrice(c.price)}</div></div><div class="car-meta"><span>${c.year}</span><span>${c.fuel}</span><span>${c.gear}</span><span>${new Intl.NumberFormat('bg-BG').format(c.mileage)} км</span><span>${c.power} к.с.</span></div><p class="snip">${c.description.slice(0,130)}…</p><div class="car-location"><span>${c.location}, ${c.seller.toLowerCase()}</span><a class="details-btn" href="car.html?id=${c.id}">Виж обявата</a></div></div>`;
    $('#carsGrid').appendChild(article);
  });
  bindCardActions();updateFavoriteCount();
}
function bindCardActions(){
  $$('[data-details]').forEach(b=>b.onclick=()=>openDetails(Number(b.dataset.details)));
  $$('[data-fav]').forEach(b=>b.onclick=()=>toggleFavorite(Number(b.dataset.fav)));
}
function toggleFavorite(id){favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];localStorage.setItem('automarket_favorites',JSON.stringify(favorites));renderCars(visibleCars);showToast(favorites.includes(id)?'Добавено в любими':'Премахнато от любими')}
function updateStats(){const a=$('#statCars'),b=$('#statCities');if(a)a.textContent=cars.length;if(b)b.textContent=new Set(cars.map(c=>c.location)).size}
function updateFavoriteCount(){updateStats();}


function getSelectedExtras(){return $$('.extraFilter:checked').map(x=>x.value)}
function applyFilters(){
  const f={brand:$('#brandFilter').value,model:$('#modelFilter').value,priceMin:+$('#priceMin').value||0,priceMax:+$('#priceMax').value||Infinity,yearMin:+$('#yearMin').value||0,yearMax:+$('#yearMax').value||Infinity,fuel:$('#fuelFilter').value,gear:$('#gearFilter').value,body:$('#bodyFilter').value,location:$('#locationFilter').value,seller:$('#sellerFilter').value,condition:$('#conditionFilter').value,mileageMax:+$('#mileageMax').value||Infinity,powerMin:+$('#powerMin').value||0,color:$('#colorFilter').value,doors:+$('#doorsFilter').value||0,drive:$('#driveFilter').value,euro:$('#euroFilter').value,wheel:$('#wheelFilter').value,posted:+$('#postedFilter').value||Infinity,extras:getSelectedExtras()};
  visibleCars=cars.filter(c=>(!f.brand||c.brand===f.brand)&&(!f.model||c.model===f.model)&&c.price>=f.priceMin&&c.price<=f.priceMax&&c.year>=f.yearMin&&c.year<=f.yearMax&&(!f.fuel||c.fuel===f.fuel)&&(!f.gear||c.gear===f.gear)&&(!f.body||c.body===f.body)&&(!f.location||c.location===f.location)&&(!f.seller||c.seller===f.seller)&&(!f.condition||c.condition===f.condition)&&c.mileage<=f.mileageMax&&c.power>=f.powerMin&&(!f.color||c.color===f.color)&&(!f.doors||c.doors===f.doors)&&(!f.drive||c.drive===f.drive)&&(!f.euro||c.euro===f.euro)&&(!f.wheel||c.wheel===f.wheel)&&c.postedDays<=f.posted&&f.extras.every(e=>(c.extras||[]).includes(e)));
  sortCars();renderActiveFilters(f);renderCars(visibleCars)
}
function renderActiveFilters(f){const labels=[];if(f.brand)labels.push(f.brand);if(f.model)labels.push(f.model);if(f.fuel)labels.push(f.fuel);if(f.gear)labels.push(f.gear);if(f.body)labels.push(f.body);if(f.location)labels.push(f.location);if(f.priceMax!==Infinity)labels.push('до '+formatPrice(f.priceMax));if(f.yearMin)labels.push('от '+f.yearMin+' г.');f.extras.forEach(x=>labels.push(x));$('#activeFilters').innerHTML=labels.map(x=>`<span class="filter-chip">${x}</span>`).join('')}
function sortCars(){const s=$('#sortSelect').value;visibleCars.sort((a,b)=>s==='priceAsc'?a.price-b.price:s==='priceDesc'?b.price-a.price:s==='yearDesc'?b.year-a.year:s==='mileageAsc'?a.mileage-b.mileage:a.postedDays-b.postedDays)}
function resetFilters(){$$('#filters input').forEach(i=>{if(i.type==='checkbox')i.checked=false;else i.value=''});$$('#filters select').forEach(s=>s.selectedIndex=0);updateModelSelect();visibleCars=[...cars];sortCars();$('#activeFilters').innerHTML='';renderCars(visibleCars)}
function quickSearch(){resetFilters();$('#brandFilter').value=$('#quickBrand').value;$('#fuelFilter').value=$('#quickFuel').value;$('#priceMax').value=$('#quickPrice').value;$('#yearMin').value=$('#quickYear').value;updateModelSelect();applyFilters();document.querySelector('#offers').scrollIntoView({behavior:'smooth'})}

function openModal(id){$('#'+id).classList.add('open');$('#'+id).setAttribute('aria-hidden','false');document.body.style.overflow='hidden';const x=$('#'+id+' .modal-close');x&&x.focus()}
function closeModal(id){$('#'+id).classList.remove('open');$('#'+id).setAttribute('aria-hidden','true');document.body.style.overflow=''}
$$('[data-close]').forEach(x=>x.onclick=()=>closeModal(x.dataset.close));
function showToast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.remove('show'),2200)}

$('#brandFilter').addEventListener('change',updateModelSelect);$('#applyFilters').onclick=()=>{applyFilters();closeFilters();document.querySelector('#offers').scrollIntoView({behavior:'smooth'})};$('#resetFilters').onclick=resetFilters;$('#sortSelect').onchange=()=>{sortCars();renderCars(visibleCars)};$('#quickSearchBtn').onclick=quickSearch;$('#showAllFilters').onclick=()=>{$('#filters').classList.add('open');$('#filters').scrollIntoView({behavior:'smooth'})};



document.addEventListener('keydown',e=>{if(e.key==='Escape')$$('.modal.open').forEach(m=>closeModal(m.id))});
fillSelects();sortCars();renderCars(visibleCars);

function closeFilters(){$('#filters').classList.remove('open');$('#toggleFilters').setAttribute('aria-expanded','false')}
$('#toggleFilters').onclick=()=>{const o=$('#filters').classList.toggle('open');$('#toggleFilters').setAttribute('aria-expanded',o)};
$('#bodyChips').innerHTML='<button class="chip active" data-body="">Всички</button>'+['Седан','Хечбек','Комби','SUV','Купе'].map(b=>`<button class="chip" data-body="${b}">${b}</button>`).join('');
$$('#bodyChips .chip').forEach(b=>b.onclick=()=>{$('#bodyFilter').value=b.dataset.body;applyFilters();$$('#bodyChips .chip').forEach(x=>x.classList.toggle('active',x===b))});
$('#resetFilters').addEventListener('click',()=>$$('#bodyChips .chip').forEach((x,i)=>x.classList.toggle('active',i===0)));

function handleHash(){if(location.hash==='#publish')location.href='publish.html';}
(()=>{const q=new URLSearchParams(location.search),m={brand:'#brandFilter',fuel:'#fuelFilter',seller:'#sellerFilter',condition:'#conditionFilter'};let any=false;for(const k in m)if(q.get(k)){$(m[k]).value=q.get(k);any=true}if(any){updateModelSelect();applyFilters()}})();
handleHash();addEventListener('hashchange',handleHash);
