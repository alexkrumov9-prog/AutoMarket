(()=>{
const $=s=>document.querySelector(s),opt=a=>a.map(x=>`<option>${x}</option>`).join('');
$('#brandList').innerHTML=opt(['Audi','BMW','Citroen','Dacia','Fiat','Ford','Honda','Hyundai','Kia','Mazda','Mercedes-Benz','Nissan','Opel','Peugeot','Renault','Seat','Skoda','Toyota','Volkswagen','Volvo']);
const ys=[];for(let y=2026;y>=1990;y--)ys.push(y);$('#year').innerHTML='<option value="">Избери</option>'+opt(ys);
let photos=[];
const shrink=f=>new Promise(res=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,1100/Math.max(im.width,im.height)),cv=document.createElement('canvas');cv.width=im.width*k;cv.height=im.height*k;cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);res(cv.toDataURL('image/jpeg',.72))};im.onerror=()=>res(null);im.src=r.result};r.readAsDataURL(f)});
function draw(){$('#previews').innerHTML=photos.map((p,i)=>`<div class="pv"><img src="${p}" alt="Снимка ${i+1}"><button type="button" class="rm" data-rm="${i}" aria-label="Премахни снимка">×</button>${i?`<button type="button" class="mk" data-main="${i}">Направи главна</button>`:'<span>Главна</span>'}</div>`).join('');$('#photoErr').hidden=photos.length>0}
$('#photoInput').onchange=async e=>{for(const f of e.target.files){if(photos.length>=8)break;if(!f.type.startsWith('image/'))continue;const s=await shrink(f);if(s)photos.push(s)}e.target.value='';draw()};
$('#previews').onclick=e=>{const t=e.target;if(t.dataset.rm)photos.splice(+t.dataset.rm,1);else if(t.dataset.main)photos.unshift(...photos.splice(+t.dataset.main,1));else return;draw()};
$('#pubForm').onsubmit=e=>{e.preventDefault();if(!photos.length){$('#photoErr').hidden=false;$('#photoErr').scrollIntoView({block:'center'});return}
const d=Object.fromEntries([...new FormData(e.target)].filter(([k])=>k!=='extra').map(([k,v])=>[k,esc(String(v).trim())]));
const car={id:Date.now(),brand:d.brand,model:d.model,title:`${d.brand} ${d.model}${d.engine?' '+d.engine:''}`,price:+d.price,year:+d.year,fuel:d.fuel,gear:d.gear,mileage:+d.mileage||0,power:+d.power||0,body:d.body,location:d.city,seller:d.seller,condition:d.condition,color:d.color,doors:+d.doors,drive:d.drive,euro:d.euro,wheel:d.wheel,postedDays:0,engine:d.engine||'—',image:photos[0],images:photos.slice(1),extras:[...document.querySelectorAll('[name=extra]:checked')].map(x=>x.value),description:d.description,phone:d.phone};
try{const u=JSON.parse(localStorage.getItem('automarket_userCars')||'[]');u.unshift(car);localStorage.setItem('automarket_userCars',JSON.stringify(u));location.href='car.html?id='+car.id}catch(x){$('#saveErr').hidden=false}};
})();
