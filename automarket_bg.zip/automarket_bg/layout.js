(()=>{
const home=!!document.getElementById('carsGrid'),here=location.pathname.split('/').pop()||'index.html';
const nav=[['index.html','Начало'],['index.html#offers','Обяви'],['index.html#how','Как работи'],['about.html','За нас'],['contact.html','Контакти'],['publish.html','Публикувай обява']];
const fav=JSON.parse(localStorage.getItem('automarket_favorites')||'[]').length;
const brand=`<svg class="brand-logo" viewBox="0 0 48 48" aria-hidden="true"><rect width="48" height="48" rx="12" fill="#d7182a"/><path d="M13 29 24 9l11 20" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path fill="#fff" d="M9 40h30v-3.2c0-1.4-1-2.6-2.4-2.9l-4-.9-2.6-3.2c-.6-.8-1.5-1.2-2.4-1.2h-8.4c-.9 0-1.8.4-2.400 1.2l-2.600 3.200-4 .9C10 34.200 9 35.400 9 36.800z"/><path fill="#d7182a" d="M16 32.700l1.700-2.100c.2-.3.500-.4.800-.4h3.300v2.500zM24.700 30.200h1.900c.3 0 .6.100.8.400l1.700 2.100h-4.400z"/><circle cx="16" cy="40" r="3.200" fill="#0a0a0b" stroke="#fff" stroke-width="1.500"/><circle cx="32" cy="40" r="3.200" fill="#0a0a0b" stroke="#fff" stroke-width="1.500"/></svg><span><strong>Auto<em>Market</em></strong></span>`;
const lnk=(h,t)=>`<a href="${h}">${t}</a>`;
const hdr=`<header class="topbar"><div class="container nav-wrap"><a class="brand" href="index.html" aria-label="AutoMarket">${brand}</a>
<nav class="nav-links" id="mainNav" aria-label="Основна навигация">${nav.map(([h,t])=>`<a href="${h}"${h===here?' aria-current="page"':''}>${t}</a>`).join('')}</nav>
<div class="nav-actions"><button class="primary-btn" id="openPublish">Публикувай обява</button><button class="menu-btn" id="menuBtn" aria-label="Меню" aria-expanded="false" aria-controls="mainNav">☰</button></div></div></header>`;
const ftr=`<footer class="site-footer"><div class="container">
<div class="footer-cta"><div><h2>Продаваш кола?</h2><p>Публикувай обявата си безплатно.</p></div><a class="cta-btn" href="publish.html">Публикувай обява</a></div>
<div class="footer-cols">
<div class="fcol brandcol"><div class="brand">${brand}</div><p>Обяви за нови и употребявани автомобили от частни лица и автокъщи в цяла България.</p></div>
<div class="fcol"><h3>Обяви</h3>${lnk('index.html#offers','Всички обяви')}${lnk('index.html?condition=Нов внос#offers','Нов внос')}${lnk('index.html?fuel=Хибрид#offers','Хибридни')}${lnk('index.html?seller=Автокъща#offers','От автокъщи')}${lnk('index.html?seller=Частно лице#offers','От частни лица')}</div>
<div class="fcol"><h3>Марки</h3>${['BMW','Audi','Mercedes-Benz','Volkswagen','Skoda','Toyota'].map(b=>lnk('index.html?brand='+b+'#offers',b)).join('')}</div>
<div class="fcol"><h3>Компания</h3>${lnk('about.html','За нас')}${lnk('index.html#how','Как работи')}${lnk('contact.html','Контакти')}${lnk('publish.html','Публикуване на обява')}</div>
<div class="fcol"><h3>Контакти</h3><p>бул. „България“ 100,<br>Пловдив 4000</p>${lnk('tel:+35932000000','032 000 000')}${lnk('mailto:office@automarket.bg','office@automarket.bg')}<p>Пн–Пт: 9:00–18:00<br>Сб: 10:00–14:00</p></div>
</div><div class="footer-bottom"><span>© 2026 AutoMarket</span></div></div></footer>`;
const m=document.querySelector('main');m.insertAdjacentHTML('beforebegin',hdr);m.insertAdjacentHTML('afterend',ftr);
document.getElementById('openPublish').onclick=()=>location.href='publish.html';
const mb=document.getElementById('menuBtn'),mn=document.getElementById('mainNav');mb.onclick=()=>{mb.setAttribute('aria-expanded',mn.classList.toggle('open'))};

const heroes=[...document.querySelectorAll('.hero,.page-hero')];
if(heroes.length){
const ids=['1503376780353-7e6692767b70','1492144534655-ae79c964c9d7','1494976388531-d1058494cdd8','1555215695-3004980ad54e','1552519507-da3b142c6e3d','1583121274602-3e2820c69888'];
const pool=ids.map(i=>`https://images.unsplash.com/photo-${i}?auto=format&fit=crop&w=1600&q=75`);
Promise.all(pool.map(u=>new Promise(r=>{const i=new Image();i.onload=()=>r(u);i.onerror=()=>r(null);i.src=u}))).then(a=>{
const ok=a.filter(Boolean);if(!ok.length)return;
heroes.forEach((h,hi)=>{
const w=document.createElement('div');w.className='hero-bg';w.setAttribute('aria-hidden','true');
w.innerHTML=ok.map(u=>`<div style="background-image:url('${u}')"></div>`).join('');
h.prepend(w);
const s=[...w.children];let cur=0,t;
const dots=document.createElement('div');dots.className='hero-dots';
dots.innerHTML=ok.length>1?ok.map((_,k)=>`<button type="button" aria-label="Снимка ${k+1}"></button>`).join(''):'';
h.append(dots);const d=[...dots.children];
const show=k=>{s[cur].classList.remove('on');d[cur]&&d[cur].classList.remove('on');cur=(k+s.length)%s.length;s[cur].classList.add('on');d[cur]&&d[cur].classList.add('on')};
const run=()=>{clearInterval(t);if(ok.length>1&&!matchMedia('(prefers-reduced-motion: reduce)').matches)t=setInterval(()=>show(cur+1),5500)};
d.forEach((b,k)=>b.onclick=()=>{show(k);run()});
cur=(here.length+hi)%s.length;s[cur].classList.add('on');d[cur]&&d[cur].classList.add('on');run();
})})}
})();
