(async()=>{
const $=s=>document.querySelector(s),nf=x=>new Intl.NumberFormat('bg-BG').format(x);
const all=[...baseCars,...JSON.parse(localStorage.getItem('automarket_userCars')||'[]')];
const c=all.find(x=>x.id===+new URLSearchParams(location.search).get('id')),root=$('#carPage');
if(!c){root.innerHTML='<div class="empty-state"><h3>Обявата не е намерена</h3><p>Може да е премахната. <a href="index.html#offers"><b>Виж всички обяви</b></a></p></div>';return}
document.title=c.title+' — AutoMarket';$('#crumb').textContent=c.title;
const fb=placeholderImage(c.title),ok=await Promise.all(carGallery(c).map(s=>new Promise(r=>{const i=new Image();i.onload=()=>r(s);i.onerror=()=>r(null);i.src=s.replace(/&amp;/g,'&')}))),imgs=ok.filter(Boolean);if(!imgs.length)imgs.push(fb);const n=imgs.length;
const specs=[['Година',c.year],['Пробег',nf(c.mileage)+' км'],['Гориво',c.fuel],['Скорости',c.gear],['Мощност',c.power+' к.с.'],['Двигател',c.engine||'—'],['Купе',c.body],['Задвижване',c.drive],['Цвят',c.color],['Евростандарт',c.euro],['Волан',c.wheel],['Врати',c.doors]];
const sim=all.filter(x=>x.id!==c.id&&(x.brand===c.brand||x.fuel===c.fuel)).slice(0,3);
root.innerHTML=`<div class="car-layout"><div class="car-main">
<div class="gallery"><div class="slides" id="slides" tabindex="0" aria-label="Снимки на автомобила">${imgs.map((s,i)=>`<img src="${s}" alt="${c.title} — снимка ${i+1}"${i?' loading="lazy"':''} onerror="this.src='${fb}'">`).join('')}</div>
${n>1?'<button class="g-btn prev" aria-label="Предишна снимка">‹</button><button class="g-btn next" aria-label="Следваща снимка">›</button>':''}<span class="g-count" id="gCount">1 / ${n}</span></div>
${n>1?`<div class="thumbs" id="thumbs">${imgs.map((s,i)=>`<button class="${i?'':'active'}" aria-label="Снимка ${i+1}"><img src="${s}" alt="" onerror="this.src='${fb}'"></button>`).join('')}</div>`:''}
${c.credit?`<p class="credit">${c.credit}</p>`:''}<h2>Описание</h2><p class="desc">${c.description}</p>
<h2>Оборудване</h2><div class="extras-list">${(c.extras||[]).map(x=>`<span>${x}</span>`).join('')||'<span>Няма добавени екстри</span>'}</div></div>
<aside class="car-side"><div class="buy-box"><span class="tag">${c.condition}</span><h1>${c.title}</h1><div class="details-price">${formatPrice(c.price)}</div><p class="loc">${c.location}, ${c.seller.toLowerCase()}</p>
<div class="spec-grid">${specs.map(x=>`<div class="spec"><small>${x[0]}</small><strong>${x[1]}</strong></div>`).join('')}</div>
<a class="primary-btn wide call" href="tel:${(c.phone||'').replace(/\s/g,'')}">${c.phone?'Обади се на '+c.phone:'Няма телефон'}</a></div></aside></div>
${sim.length?`<h2 class="sim-h">Подобни обяви</h2><div class="sim-grid">${sim.map(x=>`<a class="sim-card" href="car.html?id=${x.id}"><img src="${carGallery(x)[0]}" alt="" loading="lazy" onerror="this.src='${placeholderImage(x.title)}'"><div><strong>${x.title}</strong><span>${formatPrice(x.price)}</span></div></a>`).join('')}</div>`:''}`;
if(n>1){const sl=$('#slides'),th=[...document.querySelectorAll('#thumbs button')];let cur=0;
const go=i=>sl.scrollTo({left:((i+n)%n)*sl.clientWidth,behavior:'smooth'});
sl.addEventListener('scroll',()=>{const i=Math.round(sl.scrollLeft/sl.clientWidth);if(i!==cur){cur=i;$('#gCount').textContent=`${i+1} / ${n}`;th.forEach((t,k)=>t.classList.toggle('active',k===i))}});
$('.g-btn.prev').onclick=()=>go(cur-1);$('.g-btn.next').onclick=()=>go(cur+1);th.forEach((t,k)=>t.onclick=()=>go(k));
sl.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')go(cur-1);if(e.key==='ArrowRight')go(cur+1)})}
})();
